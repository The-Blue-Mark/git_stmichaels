$(document).ready(function() {
  
  $('.sg-item').click( function() {
    $('.sg-item').removeClass('active');
    $(this).addClass('active');
  });
  
  $('.faq-item').click( function() {
    $('.faq-item').removeClass('active');
    $(this).addClass('active');
  });

  $('.doc1').click( function() {
    $('.team-member').removeClass('active');
    $('.team-item').removeClass('active');
    $('#doc1').addClass('active');
    $(this).addClass('active');
  });

  $('.doc2').click( function() {
    $('.team-member').removeClass('active');
    $('.team-item').removeClass('active');
    $('#doc2').addClass('active');
    $(this).addClass('active');
  });

  $('.doc3').click( function() {
    $('.team-member').removeClass('active');
    $('.team-item').removeClass('active');
    $('#doc3').addClass('active');
    $(this).addClass('active');
  });

  $('.doc4').click( function() {
    $('.team-member').removeClass('active');
    $('.team-item').removeClass('active');
    $('#doc4').addClass('active');
    $(this).addClass('active');
  });

  $('.doc5').click( function() {
    $('.team-member').removeClass('active');
    $('.team-item').removeClass('active');
    $('#doc5').addClass('active');
    $(this).addClass('active');
  });

  $('.doc6').click( function() {
    $('.team-member').removeClass('active');
    $('.team-item').removeClass('active');
    $('#doc6').addClass('active');
    $(this).addClass('active');
  });

  $('.doc7').click( function() {
    $('.team-member').removeClass('active');
    $('.team-item').removeClass('active');
    $('#doc7').addClass('active');
    $(this).addClass('active');
  });

  $('.doc8').click( function() {
    $('.team-member').removeClass('active');
    $('.team-item').removeClass('active');
    $('#doc8').addClass('active');
    $(this).addClass('active');
  });

  $('.doc9').click( function() {
    $('.team-member').removeClass('active');
    $('.team-item').removeClass('active');
    $('#doc9').addClass('active');
    $(this).addClass('active');
  });

  $('.doc10').click( function() {
    $('.team-member').removeClass('active');
    $('.team-item').removeClass('active');
    $('#doc10').addClass('active');
    $(this).addClass('active');
  });

  $('.doc11').click( function() {
    $('.team-member').removeClass('active');
    $('.team-item').removeClass('active');
    $('#doc11').addClass('active');
    $(this).addClass('active');
  });

  $('.doc12').click( function() {
    $('.team-member').removeClass('active');
    $('.team-item').removeClass('active');
    $('#doc12').addClass('active');
    $(this).addClass('active');
  });

  $('.doc13').click( function() {
    $('.team-member').removeClass('active');
    $('.team-item').removeClass('active');
    $('#doc13').addClass('active');
    $(this).addClass('active');
  });

  $('.doc14').click( function() {
    $('.team-member').removeClass('active');
    $('.team-item').removeClass('active');
    $('#doc14').addClass('active');
    $(this).addClass('active');
  });

  $('.doc15').click( function() {
    $('.team-member').removeClass('active');
    $('.team-item').removeClass('active');
    $('#doc15').addClass('active');
    $(this).addClass('active');
  });

  $('.doc16').click( function() {
    $('.team-member').removeClass('active');
    $('.team-item').removeClass('active');
    $('#doc16').addClass('active');
    $(this).addClass('active');
  });

  $('.doc17').click( function() {
    $('.team-member').removeClass('active');
    $('.team-item').removeClass('active');
    $('#doc17').addClass('active');
    $(this).addClass('active');
  });

  $('.doc18').click( function() {
    $('.team-member').removeClass('active');
    $('.team-item').removeClass('active');
    $('#doc18').addClass('active');
    $(this).addClass('active');
  });

  $('.doc19').click( function() {
    $('.team-member').removeClass('active');
    $('.team-item').removeClass('active');
    $('#doc19').addClass('active');
    $(this).addClass('active');
  });

  $('.doc20').click( function() {
    $('.team-member').removeClass('active');
    $('.team-item').removeClass('active');
    $('#doc20').addClass('active');
    $(this).addClass('active');
  });

});

